# Three versions of the subject are known, in chronological order:
[nseropia-subject.en.txt](nseropia-subject.en.txt)

[tischmid previous subject](solution-tischmid/subject-old/subject.en.txt)

[tischmid new subject](solution-tischmid/subject/subject.en.txt)

