# Two versions of the subject are known, in chronological order:
[denizozd version](solution-ksansom/subject/denizozd-polyset.pdf)
[ksansom version](solution-ksansom/subject/polyset.subject.txt)
