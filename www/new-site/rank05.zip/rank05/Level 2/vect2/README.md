# Only one version of the subject is known
[denizozd version](solution-denizozd/subject/subject.en.txt)
