# Two versions of the subject are known, in chronological order:
[denizozd version](solution-denizozd/subject/bigint.subject.en.txt)

[tischmid version](solution-tischmid/subject/subject.en.txt)
